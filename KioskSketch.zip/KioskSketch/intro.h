#ifndef _INTRO_H
#define _INTRO_H

#include <arduino.h>
#include "kiosk.h"

void enter_INTRO(GameState&);
States body_INTRO(int, GameState&);

#endif
