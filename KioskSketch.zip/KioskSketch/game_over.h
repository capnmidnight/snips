#ifndef _GAME_OVER_H
#define _GAME_OVER_H

#include <arduino.h>
#include "kiosk.h"

void enter_GAME_OVER(GameState&);
States body_GAME_OVER(int, GameState&);

#endif
